<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Product Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        .product-images img {
            max-width: 150px;
            margin: 5px;
        }
    </style>
</head>
<body>
    <h1>Product Added Successfully</h1>
    <table>
        <tr>
            <th>Property</th>
            <th>Value</th>
        </tr>
        <tr>
            <td>ID</td>
            <td><?php echo e($product['id']); ?></td>
        </tr>
        <tr>
            <td>Title</td>
            <td><?php echo e($product['title']); ?></td>
        </tr>
        <tr>
            <td>Sale Price</td>
            <td>$<?php echo e($product['sale_price']); ?></td>
        </tr>
        <tr>
            <td>Stock</td>
            <td><?php echo e($product['stock']); ?></td>
        </tr>
        <tr>
            <td>Description</td>
            <td><?php echo e($product['description']); ?></td>
        </tr>
        <tr>
            <td>Images</td>
            <td class="product-images">
                <?php $__currentLoopData = $product['image']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e($image); ?>" alt="Product Image">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ecomproject-sowjanya\resources\views/email/new_product_mail.blade.php ENDPATH**/ ?>